package com.cartrack.challenge

import android.app.Application

class CartrackApplication : Application() {

    override fun onCreate() {
        super.onCreate()
    }

}